#O script pede para colocar o nome do arquivo a ser analisado.
#No zip também tem o log que foi analisado: log1.log .

import itertools
import re
import os
import statistics
listaHoras = []

dicHorasContadas = {}
contador = itertools.count()

arquivo = input('Digite o arquivo: ')

with open(os.path.dirname(os.path.realpath(__file__))+ '/'+arquivo, 'r') as f:
    print('analisando o arquivo: ', arquivo)
    print('dados encontrados:')
    for linha in f:
        if re.search("ERROR ->", linha) != None:
            #next(contador)
            print(next(contador), linha)
            hora = re.findall(r'\d{2}\W\d{2}\W\d{2}', linha)[1].split(':')[0]
            listaHoras.append(hora)
    
    print('lista das horas com erros: ', listaHoras)

    def categoria(listaHoras):
        def enxugar(listagem):
            for h in listagem[:]:
                while len(listagem) > listagem.index(h)+1:
                    #print('h', h)
                    if h == listagem[listagem.index(h)+1]:
                        listagem.remove(h)
                    else:
                        break
            return listagem
        
        def categorizar(listaH, ordem, nome):
            listaH = [h for h in listaH if listaH.count(h) == max(listaH.count(h) for h in listaH)-ordem]
            enxugar(listaH)
            return nome, listaH

        maiorH = categorizar(listaHoras, 0, 'Maior')
        segMaiorH = categorizar(listaHoras, 1, '2o maior')
        terMaiorH = categorizar(listaHoras, 2, '3o maior')
        return maiorH, segMaiorH, terMaiorH
    
    print(categoria(listaHoras))